import java.util.Scanner;

public class cwiczenie3 {
    public static void main(String[] args) {
        Scanner klawiatura = new Scanner(System.in);
        System.out.println("podaj wartosc calkowita dodatnia : ");
        int wartosc = klawiatura.nextInt();

        int i = 1;


        while ( i <= wartosc) {
         //   System.out.println(i);
          //  i +=2;
            if (i % 2 == 1) {
                System.out.print(i + " ");
            }
            i++;

        }

        for (i =1 ; i <= wartosc; i++) {
            if (i % 2 == 1 ){
                System.out.print(i + " ");

            }
            //i++;
        }

    }
}
