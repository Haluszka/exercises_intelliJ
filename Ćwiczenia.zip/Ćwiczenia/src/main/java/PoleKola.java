public class PoleKola
{ public static void main(String[] args) {
    double  promienKola = 4;
    final double PI = 3.1416;

    double poleKola;
    poleKola = PI * promienKola * promienKola;
    System.out.println("Koło o promieniu = " + promienKola + " ma pole = " + poleKola);
}
}


