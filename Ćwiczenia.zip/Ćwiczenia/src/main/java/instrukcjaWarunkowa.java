public class instrukcjaWarunkowa {

    public static void main(String[] args) {

        int zmienna=6;

        if (zmienna==5) {
            System.out.println("w pudełku jest wartosc 5");
        }else {
            System.out.println("w pudelku jest wartosc inna niż 5");
        }if (zmienna==5){
            System.out.println("w pudelku jest wartosc 5");
        }else if (zmienna==6) {
            System.out.println("w pudelku jest wartosc 6");
        }else if (zmienna==7) {
            System.out.println("w pudelku jest wartosc 7");
        }else {
            System.out.println("w pudelku nie ma ani 5 ani 6 ani 7");
        }
    }
}
