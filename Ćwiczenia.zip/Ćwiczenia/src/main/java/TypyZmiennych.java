public class TypyZmiennych {
    public static void main(String[] args) {
        byte liczbaCalkowita;
        liczbaCalkowita =3;

        double liczbaRzeczywista= 128.0 ;

        char zmiennaZnakowa = 'c';
        boolean zmiennaLogiczna = true;

        System.out.println("liczbaCalkowita =" + liczbaCalkowita + "PLN" );
        System.out.println(liczbaRzeczywista);
        System.out.println(zmiennaLogiczna);

        zmiennaLogiczna = false;
        System.out.println(zmiennaLogiczna);
        System.out.println(zmiennaZnakowa);

        System.out.println(liczbaCalkowita+ liczbaRzeczywista);
        char zmiennaZnakowa2 = 169;
        System.out.println(zmiennaZnakowa2);
        System.out.println(zmiennaZnakowa + zmiennaZnakowa2);
        final double STALA_PI = 3.1416;



    }
}





