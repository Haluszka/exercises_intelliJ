public class InstrukcjaWarunkowa3 {
    public static void main(String[] args) {

        int x=6;

        if ((x<-2) || (x>+0 && x<2) || (x>5)) {
            System.out.println("tak");
        }else
            System.out.println("nie");

    }
}
