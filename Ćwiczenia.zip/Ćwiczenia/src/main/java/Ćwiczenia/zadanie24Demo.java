package Ćwiczenia;

public class zadanie24Demo {
    public static void main(String[] args) {
        zadanie24 date1 = new zadanie24();
        date1.setDzien(24);
        date1.setMiesica(11);
        date1.setRok(2021);
        date1.wyswietlDate();
    }
}
