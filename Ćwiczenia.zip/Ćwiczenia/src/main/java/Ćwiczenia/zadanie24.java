package Ćwiczenia;

//Napisz program, który stworzy klasę o nazwie "Date", klasa powinna zawierać następujące pola:
//dzień (int)
//miesiąc (int)
//rok (int)
//Utwórz metody - gettery, settery dla każdego pola klasy.
// Utwórz metody, które wyświetlą datę - dzień, miesiąc oraz rok w formacie dd/mm/rrrr
// Napisz przykładowy kod, który zaprezentuje możliwości działania klasy.

public class zadanie24 {
   private int dzien;
   private int miesica;
   private int rok;

    public int getDzien() {
        return dzien;
    }

    public void setDzien(int dzien) {
        this.dzien = dzien;
    }

    public int getMiesica() {
        return miesica;
    }

    public void setMiesica(int miesica) {
        this.miesica = miesica;
    }

    public int getRok() {
        return rok;
    }

    public void setRok(int rok) {
        this.rok = rok;
    }
    public void wyswietlDate() {
        System.out.printf("%d/%d/%d",dzien, miesica, rok);
        //System.out.println(dzien + "/" + miesica + "/" + rok);
    }
}
