public class OperatorZnakZapytania {
    public static void main(String[] args) {
        int x = -5;
        if (x <0) {
            x = x * -1;
        } else{
            x = x;
        }
        System.out.println(x);

        x = -5;

        x = x < 0 ? -x : x;
        System.out.println(x);
    }
}

