public class cwiczenie13 {
    public static void main(String[] args) {

     //   Napisz program, który stworzy tablicę dla 10 elementów typu integer.
        //   Program powinien wypełnić tablicę losowymi liczbami z zakresu od [-10..10], a następnie:
        //
        //wydrukuje zawartość tablicy na ekran
        //wydrukuje najmniejszą (minimalną) wartość z tablicy
        //wydrukuje największą (maksymalną) wartość z tablicy


        int[] tablica = new int[10];
        int minimum, maksimum;

        for(int indeks = 0; indeks < tablica.length ; indeks++ ) {
            tablica[indeks] = (int) (Math.random() *20 -10);
        }

        minimum = tablica[0];
        maksimum = tablica[0];

        for (int indeks = 0; indeks < tablica.length; indeks++) {
            System.out.print(tablica[indeks] + " ");
            if (tablica[indeks] < minimum){
                minimum = tablica[indeks];
            }
            if (tablica[indeks] > maksimum) {
                maksimum = tablica[indeks];
            }
        }
        System.out.println("\nmaksymalna wartosc to : " + maksimum);
        System.out.println("minimalna wartosc to " + minimum);
    }
}
