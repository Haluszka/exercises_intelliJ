import java.util.Locale;

public class KlasaString {

    public static void main(String[] args) {

        int x = 1;
        char c = 'a';
        String lancuchznakow = "Ala ma kota";
        lancuchznakow = "Olek ma pasa";
        System.out.println(lancuchznakow);
        System.out.println(lancuchznakow.length());
        String lancuchznakow2 = lancuchznakow.toUpperCase();
        System.out.println(lancuchznakow);
        System.out.println(lancuchznakow2);

        String lancuchznakow3 = "Olek ma psa";

        if (lancuchznakow == lancuchznakow3) {
            System.out.println(true);




        }
        if (lancuchznakow.equals("Olek ma psa"))
            System.out.println(true);



    }
}
