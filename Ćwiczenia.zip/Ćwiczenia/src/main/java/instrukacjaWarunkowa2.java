public class instrukacjaWarunkowa2 {

    public static void main(String[] args) {
        int x=10, y=20;

        if ((x==10) && (y==20)) {
            System.out.println("to sie wykona jesli x=10 i jednosczesnie y=20");
        }
    }
}
