public class ZasiegZmiennych {

    public static void main(String[] args) {
        int x=10;

        if (x == 10){
            System.out.println("x =" + x );
            int y=20;
            System.out.println("y = " +y);
        }

        x=30;
        System.out.println("x = " + x);
        int y=40;

        x += 4;
        System.out.println(x);

        x -= 4;
        x *= 3;
        x ++;
        ++x;
    }
}
