import java.util.Scanner;

public class cwiczenie2 {
    public static void main(String[] args) {
        Scanner klawaitura = new Scanner(System.in);
        double cenaTowaru;
        double iloscRat;

        do {
        System.out.println("podaj cene towaru : ");
        cenaTowaru = klawaitura.nextDouble();
        if (cenaTowaru < 100 || cenaTowaru > 10000) {
            System.out.println("powienienes podac cene towaru miedzy 100 a 10 000");
        }
        } while (cenaTowaru < 100 || cenaTowaru > 10000);


        do {
            System.out.println("podaj ilosc rat : ");
            iloscRat = klawaitura.nextInt();
            if (iloscRat < 6 || iloscRat > 48) {
                System.out.println("powinienes podac ilosc rat miedzy 6 a 48");
            }
        } while (iloscRat < 6 || iloscRat > 48);

        double oprocentowanie = 0;

        if (iloscRat >= 6 && iloscRat<= 12) {
            oprocentowanie = 0.025;
        }else if (iloscRat >= 13 && iloscRat <= 24){
            oprocentowanie = 0.05;
        }else if (iloscRat >= 25 && iloscRat <= 48){
            oprocentowanie = 0.1;
        }
        System.out.println((cenaTowaru*oprocentowanie) +cenaTowaru/iloscRat);


    }
}
