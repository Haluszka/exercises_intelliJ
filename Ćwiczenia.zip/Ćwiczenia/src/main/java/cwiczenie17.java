import java.util.Scanner;
//    //Przeanalizuj poniższy kod, zawierający metodę fizzBuzz. Działanie programu polega
//        // na pobraniu liczby całkowitej od użytkownika i sprawdzeniu trzech warunków:
//        //
//        //jeśli liczba jest podzielna przez 3,
//        // to program powinien wydrukować słowo "fizz"
//        //jeśli liczba jest podzielna przez 5,
//        // to program powinien wydrukować słowo "buzz"
//        //jeśli liczba jest podzielna przez 3 i
//        // to program powinien wydrukować słowo "fizzbuzz"
//        //Niestety poniższy program zawiera błędy, nie kompiluje się. Popraw błędy, aby przywrócić
//        // prawidłowe działanie programu, gdy użytkownik podaje liczbę wejściową.

public class cwiczenie17 {

    public static void main(String[] args) {




        Scanner klawiatura = new Scanner(System.in);
        int pobranaWartosc = klawiatura.nextInt();

        if (pobranaWartosc % 3 == 0 ) {
            System.out.print("fizz");
        }
        if (pobranaWartosc % 5 == 0 ) {
            System.out.print("buzz");
    }

    }

}
