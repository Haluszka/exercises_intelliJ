public class Petle {

    public static void main(String[] args) {

        int zmienna = 10;

        System.out.println(" petla while");

        while (zmienna>2) {
            System.out.println(zmienna);
            //zmienna = zmienna -1;
            zmienna--;
        }
        System.out.println("koniec petli while");

        System.out.println("poczatek petli do while");

        int zmienna2 = 10;

        do{
            System.out.println(zmienna2);
            zmienna2--;
        } while (zmienna2 >= 3);

        System.out.println("koniec petli do while");

        System.out.println("poczatek petli for");
        //pierwszy parametr->drugi parametr->instrukcje->
        // trzeci parametr -> drugi parametr ->instrukcje->
        // trzeci parametr ->

        for (int zmienna3 = 10; zmienna3 >= 3; zmienna3--) {
            System.out.println(zmienna3);
        }
        System.out.println("koniec petli for");
    }
}

