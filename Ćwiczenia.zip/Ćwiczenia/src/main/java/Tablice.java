public class Tablice {
    public static void main(String[] args) {
        int[] tablica = {5,6,1,9,0};

        System.out.println(tablica[0]);
        System.out.println(tablica[4]);
        tablica[4]=7;
        System.out.println(tablica[4]);
        System.out.println("Ilosc elementow = " + tablica.length);
        // System.out.println(tablica[5]);

        int[] tablica2;
        tablica2 = new int[3];
        tablica2[0] = 4;
        tablica2[1] = 5;
        tablica2[2] = 6;

        System.out.println(tablica2[2]);
        tablica2[2] = 90;
        System.out.println(tablica2[2]);

        double[][] macierz;
        macierz = new double[3][4];
        macierz[0][0] = 3;
        macierz[1][3] = 8;

        double[][] macierz2 = {{1,2,3},{4,5,6}};
        System.out.println(macierz2[0][0]);

    }
}
