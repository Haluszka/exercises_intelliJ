public class petle2 {
    public static void main(String[] args) {
        int[] tablica = {3,5,8,1};
        //  System.out.println(tablica[0]);
        //  System.out.println(tablica[1]);

        for (int i= 0; i < tablica.length ;i++) {
            System.out.println(tablica[i]);
        }
        System.out.println("-------");

        for (int pobranyElement : tablica) {
            System.out.println(pobranyElement);
        }


        int[][] macierz = new int[2][3];
        for (int i = 0 ; i <2; i++){
            for (int j = 0; j < 3; j++){
                macierz[i][j] = 9;
            }
        }
        for (int i = 0 ; i <2; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.println(macierz[i][j]);
            }
        }

    }
}
