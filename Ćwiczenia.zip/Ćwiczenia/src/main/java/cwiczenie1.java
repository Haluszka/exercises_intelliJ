import java.util.Scanner;

public class cwiczenie1 {

    public static void main(String[] args) {
        //uzytkownik wpisuje na klawiaturze

        Scanner klawiatura = new Scanner(System.in);
        System.out.println("Podaj wartosc stopni celsjusza");
        double stopnieCelsjusza = klawiatura.nextDouble();

        //double stopnieCelsjusza = 20;
        double stopnieFahrenhita;

        stopnieFahrenhita = stopnieCelsjusza * 1.8 + 32;
        System.out.println(stopnieCelsjusza + "stopni Celsjusza, to " + stopnieFahrenhita + "stopni Fahrenhaeita");

    }
}
