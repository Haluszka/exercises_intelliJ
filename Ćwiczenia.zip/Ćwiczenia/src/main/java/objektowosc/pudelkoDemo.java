package objektowosc;

public class pudelkoDemo {
    public static void main(String[] args) {
        pudelko pudelko1 = new pudelko();
        System.out.println(pudelko1.obliczPojemnosc());

        pudelko1.setszerokosc(5.3);
        pudelko1.setGlebokosc(2);
        pudelko1.setWysokosc(10);
        System.out.println(pudelko1.obliczPojemnosc());

        pudelko pudelko2 = new pudelko();
        pudelko2.setszerokosc(100);
        pudelko2.setWysokosc(50);
        pudelko2.setGlebokosc(10);
        System.out.println(pudelko2.obliczPojemnosc());
        pudelko2.setszerokosc(-6);
        System.out.println(pudelko2.obliczPojemnosc());

        System.out.println("wysokosc pudelko1, to " + pudelko1.getwysokos());

        pudelko pudelko3 = new pudelko(10, 40, 2);
        System.out.println(pudelko3.obliczPojemnosc());


    }

}
