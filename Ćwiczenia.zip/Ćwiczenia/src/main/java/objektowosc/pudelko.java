package objektowosc;

public class pudelko {
    private double szerokosc;
    private double wysokosc;
    private double glebokosc;

    pudelko(){
        this.szerokosc = 0;
        this.glebokosc = 0;
        this.wysokosc = 0;

    }

    //pudelko pudelko3 = new pudelkko(30,40,50);
    pudelko(double szerokosc, double wysokosc, double glebokosc) {
        this.szerokosc = szerokosc;
        this.wysokosc = wysokosc;
        this.glebokosc = glebokosc;
    }

    //pudelko1.obliczpojemnosc(11);
    public void setszerokosc(double width) {
        if (width > 0) {
            szerokosc = width;
        } else {
            System.out.println("wartosc hest mniejsza niz 0, wiec nie zostala wpisana do pola szerkosc");
        }
    }
    //pudelko1.setglenkosc(6)

    public void setGlebokosc(double glebokosc) {
        this.glebokosc = glebokosc;
    }

    public void setWysokosc(double wysokosc) {
        this.wysokosc = wysokosc;
    }

    public double getwysokos() {
        return this.wysokosc;

    }

    public double getGlebokosc() {
        return glebokosc;
    }

    public double getSzerokosc() {
        return szerokosc;
    }

    public double obliczPojemnosc() {
        return szerokosc * wysokosc * glebokosc;

    }

}

